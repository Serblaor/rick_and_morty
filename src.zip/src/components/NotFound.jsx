import React from 'react'

export default function NotFound() {
  return (
    <div>
      <h2>404 NOT FOUND </h2>
      
    </div>
  )
}
