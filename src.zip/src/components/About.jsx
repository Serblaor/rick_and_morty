export default function About() {
	return (
		<div>
			<h1>Hola! Soy Sergio</h1>
			<p>Esta es mi historia...</p>
		</div>
	);
}
